package model;

public enum Currency {
	EUR, NOK, USD
}
