package model;

/**
 * Created by etien on 19/10/2017.
 */
public class UnknownCurrency extends UnknownAction {
    /**
	 * 
	 */
	private static final long serialVersionUID = -5354765194632276897L;

	public UnknownCurrency(String s) {
        super(s);
    }
}
