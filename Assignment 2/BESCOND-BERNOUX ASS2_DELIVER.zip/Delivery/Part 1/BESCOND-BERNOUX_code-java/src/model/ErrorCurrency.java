package model;

/**
 * Created by etien on 19/10/2017.
 */
public class ErrorCurrency extends Error {
    public ErrorCurrency (String currency) {
        super(currency);
    }
}
