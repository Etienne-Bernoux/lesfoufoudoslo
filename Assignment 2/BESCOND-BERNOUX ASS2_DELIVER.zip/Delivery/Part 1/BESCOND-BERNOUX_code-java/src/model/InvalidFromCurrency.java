package model;

public class InvalidFromCurrency extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2582793223109835211L;

}
