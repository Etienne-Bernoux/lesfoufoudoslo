BESCOND Alexandre 		alexabes@student.matnat.uio.no
BERNOUX Etienne			etiennb@student.matnat.uio.no

Student at University of Oslo.

# Open distributed processing - Assignment n°3


## Run

• rull-all.ps1: 
	Usage: $./rull-all.ps1

• gnuplot:
	go to ./plot directory and doucle-click your desired gnuplot script. 	


## The code

The source code is located at "./BESCOND-BERNOUX_code-java".

## Prerequisites

• JavaSE 1.8 
• Permission to run script

## Help

If you have trouble to execute to code, feel free to ask your question by mail.
