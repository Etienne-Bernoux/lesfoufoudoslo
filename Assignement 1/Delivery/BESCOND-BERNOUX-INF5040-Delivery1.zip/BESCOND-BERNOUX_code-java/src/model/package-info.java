/**
 * This package implement all distributed object such as Song, TopTen and User.
 * 
 * @author Alexandre Bescond
 * @author Etienne Bernnoux
 */
package model;